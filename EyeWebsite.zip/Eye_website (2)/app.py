import os
from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

# Build absolute path to instance/products.db
basedir = os.path.abspath(os.path.dirname(__file__))
db_path = os.path.join(basedir, 'instance', 'products.db')

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + db_path
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your_secret_key_here'

# Upload folder for images
UPLOAD_FOLDER = os.path.join(basedir, 'static', 'images')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

db = SQLAlchemy(app)

# Product model
class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    molecule = db.Column(db.String(100), nullable=True)
    price = db.Column(db.Float, nullable=False)
    description = db.Column(db.Text, nullable=True)
    image_url = db.Column(db.String(200), nullable=True)

# User model (for admin login)
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    is_super = db.Column(db.Boolean, default=False)

# Homepage
@app.route('/')
def index():
    products = Product.query.all()
    return render_template('index.html', products=products)

# Product detail
@app.route('/product/<int:product_id>')
def product_detail(product_id):
    product = Product.query.get_or_404(product_id)
    return render_template('product_detail.html', product=product)

# Search
@app.route('/search')
def search():
    query = request.args.get('q', '')
    results = Product.query.filter(
        (Product.name.ilike(f"%{query}%")) |
        (Product.molecule.ilike(f"%{query}%"))
    ).all()
    return render_template('products.html', products=results, query=query)

# Secret login route
@app.route('/admin/W-kamau444', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            session['logged_in'] = True
            session['username'] = user.username
            return redirect(url_for('index'))
        else:
            return "Invalid credentials"
    return render_template('login.html')

# Logout
@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    session.pop('username', None)
    return redirect(url_for('index'))

# Admin add product
@app.route('/admin/add_product', methods=['GET', 'POST'])
def add_product():
    if not session.get('logged_in'):
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = request.form['name']
        molecule = request.form['molecule']
        price = float(request.form['price'])
        description = request.form['description']

        # Handle image upload OR URL
        image_url = None
        if 'image' in request.files and request.files['image'].filename != '':
            image_file = request.files['image']
            filename = secure_filename(image_file.filename)
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            image_file.save(image_path)
            image_url = f"/static/images/{filename}"
        elif request.form.get('image_url'):
            image_url = request.form['image_url']

        new_product = Product(
            name=name,
            molecule=molecule,
            price=price,
            description=description,
            image_url=image_url
        )
        db.session.add(new_product)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('add_product.html')

# Admin edit product
@app.route('/admin/edit_product/<int:product_id>', methods=['GET', 'POST'])
def edit_product(product_id):
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    product = Product.query.get_or_404(product_id)
    if request.method == 'POST':
        product.name = request.form['name']
        product.molecule = request.form['molecule']
        product.price = float(request.form['price'])
        product.description = request.form['description']

        if 'image' in request.files and request.files['image'].filename != '':
            image_file = request.files['image']
            filename = secure_filename(image_file.filename)
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            image_file.save(image_path)
            product.image_url = f"/static/images/{filename}"
        elif request.form.get('image_url'):
            product.image_url = request.form['image_url']

        db.session.commit()
        return redirect(url_for('product_detail', product_id=product.id))
    return render_template('edit_product.html', product=product)

# Admin delete product
@app.route('/admin/delete_product/<int:product_id>', methods=['POST'])
def delete_product(product_id):
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    product = Product.query.get_or_404(product_id)
    db.session.delete(product)
    db.session.commit()
    return redirect(url_for('index'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        # Create super user if none exists
        if not User.query.filter_by(username="admin9911").first():
            super_user = User(
                username="admin9911",
                password_hash=generate_password_hash("Cyporineyedrug"),
                is_super=True
            )
            db.session.add(super_user)
            db.session.commit()
    app.run(debug=False, port=30001)
