// --- CATEGORY FILTER ---
function filterProducts(category) {
  const cards = document.querySelectorAll('.product-card');
  document.querySelectorAll('.filter-chip').forEach(btn => btn.classList.remove('active'));

  // highlight clicked chip
  event.target.classList.add('active');

  cards.forEach(card => {
    const molecule = card.dataset.molecule;
    if (category === 'all' || molecule.includes(category)) {
      card.style.display = 'flex';
    } else {
      card.style.display = 'none';
    }
  });
}

// --- SEARCH FILTER ---
function searchProducts(event) {
  event.preventDefault();
  const query = document.getElementById('searchInput').value.toLowerCase();
  const cards = document.querySelectorAll('.product-card');

  cards.forEach(card => {
    const name = card.dataset.name;
    const molecule = card.dataset.molecule;
    if (name.includes(query) || molecule.includes(query)) {
      card.style.display = 'flex';
    } else {
      card.style.display = 'none';
    }
  });
}

// --- ADMIN MENU TOGGLE ---
document.addEventListener("DOMContentLoaded", () => {
  // Toggle dropdown when clicking the three-dot button
  document.querySelectorAll(".menu-btn").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation(); // prevent bubbling
      const menu = e.target.closest(".admin-menu");
      menu.classList.toggle("active");
    });
  });

  // Close dropdowns when clicking outside
  document.addEventListener("click", (e) => {
    document.querySelectorAll(".admin-menu").forEach(menu => {
      if (!menu.contains(e.target)) {
        menu.classList.remove("active");
      }
    });
  });
});
